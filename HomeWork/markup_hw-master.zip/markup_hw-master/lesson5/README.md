# Домашнее задание. Верстка. Урок 5.

## Задание 1

Файл task1.html

Необходимо сверстать меню из макета menu1.png использую inline-block.

Можно использовать свои наработки из lesson4 - task1

![task1.png](https://raw.githubusercontent.com/puzankov/markup_hw/master/lesson5/task1.png)

Линия растянута на всю ширину страницы. Само меню шириной 900px и центрируется.
 
Шрифт рекомендую - Impact. 

По наведению на пункты меню появляется нижняя серая строка с меню 2го уровня. 

По умолчанию (без наведения на меню) - нижней строки нет.


## Задание 2

Файл task2.html

Необходимо сверстать  макет из файла task2.psd.

![task2.png](https://raw.githubusercontent.com/puzankov/markup_hw/master/lesson5/task2.png)
