# Домашнее задание. Верстка. Урок 6.

## Задание 1

Файл task1.html

Необходимо сверстать макет из файла task1.psd.

Можно использовать свои наработки из lesson5 - task2

![task1.png](https://raw.githubusercontent.com/puzankov/markup_hw/master/lesson6/task1.png)

## Задание 2

Файл task2.html

Необходимо сверстать макет из файла task2.psd.

![task2.png](https://raw.githubusercontent.com/puzankov/markup_hw/master/lesson6/task2.png)
