# Домашнее задание. Верстка. Урок 4.

## Задание 1

Файл task1.html

Необходимо сверстать меню из макета menu1.png использую inline-block.

![menu1.png](https://raw.githubusercontent.com/puzankov/markup_hw/master/lesson4/menu1.png)

Линия растянута на всю ширину страницы. Само меню шириной 900px и центрируется.
 
Шрифт рекомендую - Impact. 

## Задание 2

Файл task2.html

Необходимо сверстать меню из макета menu2.png использую float.

![menu2.png](https://raw.githubusercontent.com/puzankov/markup_hw/master/lesson4/menu2.png)

Линия растянута на всю ширину страницы. Само меню шириной 900px и центрируется.

Шрифт рекомендую - Impact.

## Задание 3

Файл task3.html

Необходимо сверстать пейджер из макета pager.png.

![pager.png](https://raw.githubusercontent.com/puzankov/markup_hw/master/lesson4/pager.png)
